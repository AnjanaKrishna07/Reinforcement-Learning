# === environment.py ===
import tkinter as tk
import numpy as np
import time

class Env:
    def __init__(self, render=False):
        self.render_enabled = render
        self.grid_size = 5
        self.goal = [4, 4]
        self.state = [0, 0]
        self.obstacles = [[2, 2], [3, 1], [1, 3]]
        self.action_space = [0, 1, 2, 3, 4]  # Up, Down, Left, Right, Stay
        self.state_size = self.grid_size * self.grid_size
        self.action_size = len(self.action_space)

        if self.render_enabled:
            self._build_gui()

    def _build_gui(self):
        self.window = tk.Tk()
        self.window.title("Reinforce")
        self.canvas = tk.Canvas(self.window, width=250, height=250)
        self.canvas.pack()

    def reset(self):
        self.state = [0, 0]
        if self.render_enabled:
            self._draw_grid()
        return self._get_state()

    def step(self, action):
        y, x = self.state
        if action == 0 and y > 0: y -= 1     # up
        if action == 1 and y < self.grid_size - 1: y += 1 # down
        if action == 2 and x > 0: x -= 1     # left
        if action == 3 and x < self.grid_size - 1: x += 1 # right

        self.state = [y, x]

        reward = -0.1
        done = False

        if self.state == self.goal:
            reward = 10
            done = True
        elif self.state in self.obstacles:
            reward = -5

        if self.render_enabled:
            self._draw_grid()
            time.sleep(0.05)

        return self._get_state(), reward, done

    def _get_state(self):
        grid = np.zeros((self.grid_size, self.grid_size))
        y, x = self.state
        grid[y][x] = 1
        return grid.flatten()

    def _draw_grid(self):
        self.canvas.delete("all")
        cell_size = 50
        for i in range(self.grid_size):
            for j in range(self.grid_size):
                x1, y1 = j * cell_size, i * cell_size
                x2, y2 = x1 + cell_size, y1 + cell_size
                self.canvas.create_rectangle(x1, y1, x2, y2, fill='white')

        for ob in self.obstacles:
            self._draw_cell(ob[1], ob[0], "red")
        self._draw_cell(self.goal[1], self.goal[0], "green")
        self._draw_cell(self.state[1], self.state[0], "blue")

        self.window.update()

    def _draw_cell(self, x, y, color):
        cell_size = 50
        x1, y1 = x * cell_size + 5, y * cell_size + 5
        x2, y2 = x1 + 40, y1 + 40
        self.canvas.create_oval(x1, y1, x2, y2, fill=color)
